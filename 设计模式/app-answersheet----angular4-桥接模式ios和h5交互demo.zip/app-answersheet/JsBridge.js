// js与ios、android的webview交互类
class JsBridge {
  setupWebViewJavascriptBridge (callback) {
    if (window.WebViewJavascriptBridge) {
      return callback(window.WebViewJavascriptBridge)
    }
    if (window.WVJBCallbacks) {
      return window.WVJBCallbacks.push(callback)
    }
    window.WVJBCallbacks = [callback]
    let WVJBIframe = document.createElement('iframe')
    WVJBIframe.style.display = 'none'
    WVJBIframe.src = 'https://__bridge_loaded__'
    document.documentElement.appendChild(WVJBIframe)
    setTimeout(() => { document.documentElement.removeChild(WVJBIframe) }, 0)
  }
  // /**
  //  * 函数描述：js调用webview事件
  //  *
  //  * jsBridge.callHandler(method, data, callBack(response));
  //  * @param method {string} 方法名
  //  * @param data {Object} 参数
  //  * @return {Object} 回调
  //  */
  callhandler (name, data, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler(name, data, callback)
    })
  }
  // /**
  //  * 函数描述：webView调用JS事件
  //  *
  //  * jsBridge.registerHandler(method, callBack(response));
  //  * @param method {string} 方法名
  //  * @return {Object} 回调
  //  */
  registerhandler (name, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler(name, function (data, responseCallback) {
        callback(data, responseCallback)
      })
    })
  }
}

export default new JsBridge()
