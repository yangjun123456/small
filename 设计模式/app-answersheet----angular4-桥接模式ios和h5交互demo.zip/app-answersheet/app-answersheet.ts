import { Component, OnInit } from '@angular/core';
import { setInterval, log } from 'core-js/library/web/timers';
import JsBridge from './JsBridge'

declare const Swiper: any;
@Component({
  selector: 'app-answersheet',
  templateUrl: './app-answersheet.html',
  styleUrls: ['./app-answersheet.less']
})
export class AppAnswersheetComponent implements OnInit {
  //下一页控制
  num = [, , , , , , , , ,,,,,,,,,,];
  mySwiper: any;
  constructor() {
  }
  ngOnInit() {
    this.mySwiper = new Swiper('.swiper-container', {
      // direction: 'vertical',
      loop: false,
      // 如果需要分页器
      pagination: '.swiper-pagination',
      // 如果需要前进后退按钮
      nextButton: '.swiper-button-next',
      prevButton: '.swiper-button-prev',
      // 如果需要滚动条
      // scrollbar: '.swiper-scrollbar',
    })
    $('.next').click(() => {
      this.mySwiper.slideNext();
    })
    
    // js注册方法，供ios调用
    JsBridge.registerhandler("callStart", (response) => {

    })
  }
  //生命周期钩子
  ngAfterViewInit(){
    $(".bot_border1").css({"display":"none"});
  }
  //点击导航条跳转到指定题目
  setPage(pages: any) { 
    // console.log(this.mySwiper, this.mySwiper.slideTo);
    this.mySwiper.slideTo(pages, 1000, false);
  }
  //配对题
  pair1:any = null;
  pair2:any = null;
  pair3:any = null;
  pair4:any = null;
  setState(params:any){
      if(params==1){
        $(".chock1").attr("disabled",true);
      }else  if(params==2){
        $(".chock2").attr("disabled",true);
      }else  if(params==3){
        $(".chock3").attr("disabled",true);
      }else  if(params==4){
        $(".chock4").attr("disabled",true);
      }
      if(this.pair1==null){
        this.pair1 ="选题"+params;
      }else if(this.pair2==null&&this.pair1!==null){
        this.pair2 ="选题"+params;
      }else if(this.pair3==null&&this.pair1!==null&&this.pair2!==null){
        this.pair3 ="选题"+params;
      }else if(this.pair4==null&&this.pair1!==null&&this.pair2!==null&&this.pair3!==null){
        this.pair4 ="选题"+params;
      }
      if(this.pair1!==null&&this.pair2!==null){
        let str =this.pair1+"和"+this.pair2;
        $(".pair_1").text(str);
        $(".pair_1").css({"visibility":"visible"});
      }
      if(this.pair3!==null&&this.pair4!==null){
        let str =this.pair3+"和"+this.pair4;
        $(".pair_2").text(str);
        $(".pair_2").css({"visibility":"visible"});
      }
      if(this.pair3!==null&&this.pair4!==null&&this.pair1!==null&&this.pair2!==null){
        this.pair1 = null;
        this.pair2 = null;
        this.pair3 = null;
        this.pair4 = null;
      }
  }
  //重置配对题答案
  clearAnswer(){
    this.pair1 = null;
    this.pair2 = null;
    this.pair3 = null;
    this.pair4 = null;
    $(".pair_2").css({"visibility":"hidden"});
    $(".pair_1").css({"visibility":"hidden"});
    $(".chock1")[0].checked = false;
    $(".chock2")[0].checked = false;
    $(".chock3")[0].checked = false;
    $(".chock4")[0].checked = false;
    $(".chock1").attr("disabled",false);
    $(".chock2").attr("disabled",false);
    $(".chock3").attr("disabled",false);
    $(".chock4").attr("disabled",false);
  }
  startDidClick(){
    // js 调用原生的方法
    //第一种没有参数 没有回调的
    // JsBridge.callhandler("startDidClick");
    // 参数为空，有回调的
    JsBridge.callhandler("startDidClick", null, (response) => {
      console.log(response)
    });
  }
  callStart(){

  }
  submitDidClick(){
    alert(2);
  }
  callSubmint(){
    
  }
}